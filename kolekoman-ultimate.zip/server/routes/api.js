const express=require("express"),fs=require("fs"),path=require("path");
module.exports=deps=>{
 const r=express.Router(); const {db,save,uid,now,userById,userByUsername,chatById,messages,publicUser}=deps;
 const uploadDir=path.join(__dirname,"..","uploads");fs.mkdirSync(uploadDir,{recursive:true});
 r.get("/health",(_,res)=>res.json({ok:true,users:db.users.length,chats:db.chats.length,messages:db.messages.length}));
 r.post("/auth/register",(req,res)=>{
  const username=String(req.body.username||"").trim().replace(/^@/,"").toLowerCase(),name=String(req.body.name||"").trim();
  if(!/^[a-z0-9_]{3,24}$/.test(username))return res.status(400).json({error:"Username باید ۳ تا ۲۴ کاراکتر انگلیسی، عدد یا _ باشد."});
  if(name.length<2)return res.status(400).json({error:"نام را وارد کنید."});
  if(userByUsername(username))return res.status(409).json({error:"این username قبلاً ثبت شده."});
  const u={id:uid("u"),username,name,bio:"",phone:"",avatar:"",settings:{},createdAt:now()};db.users.push(u);save();res.json({user:publicUser(u)});
 });
 r.post("/auth/login",(req,res)=>{
  const u=userByUsername(req.body.username);if(!u)return res.status(404).json({error:"کاربر پیدا نشد."});res.json({user:publicUser(u)});
 });
 r.get("/users/search",(req,res)=>{
  const q=String(req.query.q||"").trim().toLowerCase().replace(/^@/,"");if(q.length<2)return res.json([]);
  res.json(db.users.filter(u=>u.username.includes(q)||u.name.toLowerCase().includes(q)).slice(0,30).map(u=>publicUser(u)));
 });
 r.get("/users/:id",(req,res)=>{const u=userById(req.params.id);if(!u)return res.status(404).json({error:"کاربر پیدا نشد."});res.json(publicUser(u))});
 r.patch("/users/:id",(req,res)=>{
  const u=userById(req.params.id);if(!u)return res.status(404).json({error:"کاربر پیدا نشد."});
  for(const k of ["name","bio","phone","avatar"])if(req.body[k]!==undefined)u[k]=String(req.body[k]).slice(0,800000);
  u.settings=req.body.settings||u.settings;save();res.json({user:publicUser(u)});
 });
 r.get("/chats/:userId",(req,res)=>{
  const id=req.params.userId;res.json(db.chats.filter(c=>c.members?.includes(id)).map(c=>{
   const last=messages(c.id).at(-1),other=c.type==="private"?db.users.find(u=>c.members.includes(u.id)&&u.id!==id):null;
   return {...c,other:other?publicUser(other):null,lastMessage:last||null}
  }).sort((a,b)=>new Date(b.lastMessage?.createdAt||0)-new Date(a.lastMessage?.createdAt||0)));
 });
 r.get("/chats/:chatId/messages",(req,res)=>res.json(messages(req.params.chatId)));
 r.post("/chats/private",(req,res)=>{
  const a=String(req.body.userId||""),t=userByUsername(req.body.targetUsername);if(!a||!t||a===t.id)return res.status(400).json({error:"کاربر نامعتبر."});
  const ids=[a,t.id].sort(),id="p_"+ids.join("_");let c=chatById(id);
  if(!c){c={id,type:"private",members:ids,createdAt:now()};db.chats.push(c);save()}
  res.json({...c,other:publicUser(t)});
 });
 r.post("/chats/group",(req,res)=>{
  const ownerId=req.body.ownerId,name=String(req.body.name||"").trim(),members=[...new Set([ownerId,...(req.body.memberIds||[])])].filter(x=>userById(x));
  if(!ownerId||!name)return res.status(400).json({error:"نام گروه الزامی است."});
  const c={id:uid("g"),type:"group",name:name.slice(0,80),members,ownerId,admins:[ownerId],permissions:{delete:true,ban:true,add:true,pin:true,video:true},createdAt:now()};
  db.chats.push(c);db.messages.push({id:uid("m"),chatId:c.id,fromId:ownerId,type:"system",text:`گروه «${c.name}» ساخته شد.`,createdAt:now(),status:"read",reactions:{}});save();res.json(c);
 });
 r.post("/chats/channel",(req,res)=>{
  const ownerId=req.body.ownerId,name=String(req.body.name||"").trim();if(!ownerId||!name)return res.status(400).json({error:"نام کانال الزامی است."});
  const c={id:uid("c"),type:"channel",name:name.slice(0,80),username:String(req.body.username||"").replace(/^@/,"").toLowerCase(),members:[ownerId],ownerId,admins:[ownerId],subscribers:1,views:0,createdAt:now()};
  db.chats.push(c);save();res.json(c);
 });
 r.patch("/chats/:chatId",(req,res)=>{const c=chatById(req.params.chatId);if(!c)return res.status(404).json({error:"چت پیدا نشد"});for(const k of ["name","username","avatar"])if(req.body[k]!==undefined)c[k]=String(req.body[k]).slice(0,500000);save();res.json(c)});
 r.post("/upload",(req,res)=>{
  const data=String(req.body.data||"");if(!data.includes(","))return res.status(400).json({error:"فایل نامعتبر"});
  const name=String(req.body.name||"file"),mime=String(req.body.mime||"application/octet-stream"),raw=Buffer.from(data.split(",")[1],"base64");
  if(raw.length>20*1024*1024)return res.status(413).json({error:"حداکثر حجم ۲۰ مگابایت"});
  const ext=(name.split(".").pop()||"bin").replace(/[^a-z0-9]/gi,"").slice(0,8)||"bin",fn=uid("f")+"."+ext;fs.writeFileSync(path.join(uploadDir,fn),raw);res.json({url:`/uploads/${fn}`,name,mime,size:raw.length});
 });
 r.get("/calls/:userId",(req,res)=>res.json(db.calls.filter(c=>c.fromId===req.params.userId||c.toId===req.params.userId).slice(-100).reverse()));
 return r;
}