# Kolekoman Ultimate

نسخه‌ی بزرگ‌تر و پایدارتر Kolekoman با Vanilla JS + Node.js + Express + Socket.IO.

## اجرا
```bash
npm install
npm start
```
بعد:
`http://localhost:5500`

دو تب مرورگر باز کنید، دو username متفاوت بسازید و چت کنید.

## توجه مهم
`npm install` یک‌بار لازم است چون `express` و `socket.io` dependency هستند.

نسخه‌ی Ultimate دارای fallback آفلاین سمت کلاینت است؛ حتی اگر اتصال WebSocket قطع باشد، UI سفید نمی‌شود و حالت اتصال را نشان می‌دهد.

## قابلیت‌های اصلی
- چند کاربر و چت Real-time
- ورود/ثبت‌نام
- Online / Offline / Last Seen
- Typing
- پیام متنی
- Reply / Edit / Delete / Forward
- Pin / Reaction / Multi-select
- Photo / Video / File / Voice
- Poll / Location
- Drag & Drop
- گروه و کانال
- پروفایل و تنظیمات پیشرفته
- Appearance / Privacy / Notifications / Data & Storage / Chat Settings / Language
- چندین رنگ Accent
- اندازه فونت، فشردگی چت، انیمیشن، کاهش حرکت
- Wallpaper gallery
- Auto download و Data Saver mock
- Notification sounds
- keyboard shortcuts
- mobile layout
- call UI mock
