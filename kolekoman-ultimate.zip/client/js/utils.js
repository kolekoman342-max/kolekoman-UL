export const $=(s,r=document)=>r.querySelector(s);
export const $$=(s,r=document)=>[...r.querySelectorAll(s)];
export const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
export const uid=()=>crypto.randomUUID?.()||"x"+Date.now()+Math.random();
export function toast(t){const x=$("#toast");x.textContent=t;x.classList.add("show");setTimeout(()=>x.classList.remove("show"),1900)}
export function fmt(t){let s=esc(t);s=s.replace(/\*\*(.+?)\*\*/g,"<strong>$1</strong>").replace(/__(.+?)__/g,"<em>$1</em>").replace(/~~(.+?)~~/g,"<del>$1</del>").replace(/`(.+?)`/g,"<code>$1</code>").replace(/\|\|(.+?)\|\|/g,"<span class='spoiler'>$1</span>");return s.replace(/\n/g,"<br>")}
