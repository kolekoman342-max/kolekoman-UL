import {api} from "./api.js";import {modal,close} from "./ui.js";import {$} from "./utils.js";
const KEY="k_session";
export const session=()=>localStorage.getItem(KEY);
export const logout=()=>{localStorage.removeItem(KEY);location.reload()};
export function auth(done){
 modal(`<div class="auth-card"><div class="auth-logo">K</div><h2 style="text-align:center">Kolekoman</h2><p class="auth-sub">پیام‌رسان شخصی، گروهی و Real-time</p><div class="field"><label>نام</label><input id="an" placeholder="مثلاً علی"></div><div class="field"><label>Username</label><input id="au" placeholder="ali_dev"></div><button id="go" class="primary">ورود / ساخت حساب</button><div id="ae" class="error"></div></div>`);
 $("#go").onclick=async()=>{try{let u=$("#au").value.trim(),n=$("#an").value.trim(),r;try{r=await api("/api/auth/login",{method:"POST",body:JSON.stringify({username:u})})}catch{r=await api("/api/auth/register",{method:"POST",body:JSON.stringify({username:u,name:n||u})})}localStorage.setItem(KEY,r.user.id);close();done(r.user)}catch(e){$("#ae").textContent=e.message}}
}
