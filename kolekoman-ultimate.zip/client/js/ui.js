import {$,esc} from "./utils.js";
export function av(u,big=false){return `<div class="avatar ${big?"big":""}" style="background:${u?.color||"#4f83d8"}">${esc((u?.avatar||u?.name||"K").slice(0,1))}</div>`}
export function modal(html){$("#overlayRoot").innerHTML=`<div class="modal-bg">${html}</div>`}
export function close(){ $("#overlayRoot").innerHTML=""}
export function drawer(user,items){
 $("#overlayRoot").innerHTML=`<div class="backdrop" id="drawerBg"><aside class="drawer"><div class="drawer-user">${av(user,true)}<h3>${esc(user.name)}</h3><small style="color:var(--muted)">@${esc(user.username||"")}</small></div>${items.map(i=>`<button class="drawer-btn ${i.danger?"danger":""}" data-x="${i.id}">${i.icon} ${i.label}</button>`).join("")}</aside></div>`;
 const b=$("#drawerBg");b.onclick=e=>{if(e.target===b)close()};items.forEach(i=>b.querySelector(`[data-x="${i.id}"]`).onclick=()=>{close();i.go()})
}
