import {esc,fmt} from "./utils.js";
export function html(m,me,isGroup){
 if(m.type==="system")return `<div class="message system" data-id="${m.id}"><div class="bubble">${esc(m.text)}</div></div>`;
 const own=m.fromId===me.id,reply=m.replyTo?`<div class="reply" data-reply="${m.replyTo.id}">↩ ${esc(m.replyTo.text||"پیام")}</div>`:"";
 let body="";
 if(m.media?.kind==="image")body=`<img class="msg-image" src="${esc(m.media.url)}" data-light="${esc(m.media.url)}">`;
 else if(m.media?.kind==="video")body=`<video controls src="${esc(m.media.url)}" style="max-width:340px;border-radius:10px"></video>`;
 else if(m.media?.kind==="voice")body=`<div class="file">🎙️ <div><b>پیام صوتی</b><small>${esc(m.media.duration||"")} ثانیه</small></div><button>▶</button></div>`;
 else if(m.media)body=`<div class="file">📄 <div><b>${esc(m.media.name)}</b><small>${esc(m.media.sizeText||"")}</small></div><button>↓</button></div>`;
 else if(m.poll)body=`<div><b>📊 ${esc(m.poll.question)}</b>${m.poll.options.map(o=>`<div class="poll-option"><button><span>${esc(o.text)}</span><b>${o.votes||0}%</b></button><div class="pollbar"><span style="width:${o.votes||0}%"></span></div></div>`).join("")}</div>`;
 else if(m.location)body=`<div class="location"><b>📍 موقعیت مکانی</b><div class="map">📍</div><small>${esc(m.location.label)}</small></div>`;
 else body=fmt(m.text||"");
 const react=Object.entries(m.reactions||{}).map(([e,n])=>`<span class="reaction">${e} ${n}</span>`).join("");
 return `<div class="message ${own?"out":"in"}" data-id="${m.id}"><div class="bubble">${isGroup&&!own?`<div class="sender">${esc(m.senderName||"کاربر")}</div>`:""}${m.forwardedFrom?`<div class="forwarded">↗ فوروارد شده از ${esc(m.forwardedFrom)}</div>`:""}${reply}${body}<span class="meta">${new Date(m.createdAt).toLocaleTimeString("fa-IR",{hour:"2-digit",minute:"2-digit"})}${m.edited?" · ویرایش":""} ${own?`<span class="${m.status==="read"?"read":""}">✓✓</span>`:""}</span>${react?`<div class="reaction-line">${react}</div>`:""}</div></div>`
}
